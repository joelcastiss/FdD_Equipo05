import 'package:flutter/material.dart';
import '../services/firebase_service.dart';

class StatusScreen extends StatefulWidget {
  const StatusScreen({super.key});

  @override
  State<StatusScreen> createState() => _StatusScreenState();
}

class _StatusScreenState extends State<StatusScreen> {

  final FirebaseService firebaseService = FirebaseService();

  bool wifi = false;
  bool refrigeracion = false;
  bool ventilador = false;

  @override
  void initState() {
    super.initState();

    firebaseService.getData().listen((event) {

      if (event.snapshot.value != null) {

        final data =
            event.snapshot.value as Map<dynamic, dynamic>;

        setState(() {

          wifi = data["wifi"] ?? false;

          refrigeracion =
              data["refrigeracion"] ?? false;

          ventilador =
              data["ventilador"] ?? false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: const Color(0xFFF5F7FA),

      appBar: AppBar(
        title: const Text("Estado del Sistema"),
        centerTitle: true,
      ),

      body: Padding(
        padding: const EdgeInsets.all(16),

        child: Column(
          children: [

            statusCard(
              "WiFi",
              wifi,
              Icons.wifi,
            ),

            const SizedBox(height: 15),

            statusCard(
              "Sistema de Refrigeración",
              refrigeracion,
              Icons.ac_unit,
            ),

            const SizedBox(height: 15),

            statusCard(
              "Ventilador",
              ventilador,
              Icons.air,
            ),

            const SizedBox(height: 25),

            Card(
              elevation: 3,

              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),

              child: const Padding(
                padding: EdgeInsets.all(20),

                child: Row(
                  children: [

                    Icon(
                      Icons.info,
                      color: Colors.blue,
                    ),

                    SizedBox(width: 10),

                    Expanded(
                      child: Text(
                        "Todos los componentes están siendo monitoreados en tiempo real mediante Firebase.",
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget statusCard(
    String title,
    bool state,
    IconData icon,
  ) {

    return Card(
      elevation: 4,

      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),

      child: ListTile(

        leading: Icon(
          icon,
          size: 35,
          color: state
              ? Colors.green
              : Colors.red,
        ),

        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),

        subtitle: Text(
          state
              ? "Activo"
              : "Inactivo",
        ),

        trailing: Icon(
          state
              ? Icons.check_circle
              : Icons.cancel,
          color: state
              ? Colors.green
              : Colors.red,
        ),
      ),
    );
  }
}