import 'package:flutter/material.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        "Próximamente gráficas",
        style: TextStyle(fontSize: 22),
      ),
    );
  }
}