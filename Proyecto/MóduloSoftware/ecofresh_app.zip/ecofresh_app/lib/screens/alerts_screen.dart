import 'package:flutter/material.dart';
import '../services/firebase_service.dart';

class AlertsScreen extends StatefulWidget {
  const AlertsScreen({super.key});

  @override
  State<AlertsScreen> createState() => _AlertsScreenState();
}

class _AlertsScreenState extends State<AlertsScreen> {

  final FirebaseService firebaseService = FirebaseService();

  double temperatura = 0;
  double eco2 = 0;
  double tvoc = 0;

  @override
  void initState() {
    super.initState();

    firebaseService.getData().listen((event) {

      if (event.snapshot.value != null) {

        final data =
            event.snapshot.value as Map<dynamic, dynamic>;

        setState(() {

          temperatura =
              double.tryParse(data["temperatura"].toString()) ?? 0;

          eco2 =
              double.tryParse(data["eco2"].toString()) ?? 0;

          tvoc =
              double.tryParse(data["tvoc"].toString()) ?? 0;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {

    List<Widget> alerts = [];

    if (temperatura > 8) {
      alerts.add(
        alertCard(
          "Temperatura elevada",
          "La temperatura supera los 8°C. Los alimentos podrían deteriorarse más rápido.",
          Icons.thermostat,
          Colors.red,
        ),
      );
    }

    if (eco2 > 1000) {
      alerts.add(
        alertCard(
          "Posible deterioro de alimentos",
          "El nivel de eCO₂ es alto y podría indicar descomposición.",
          Icons.warning_amber,
          Colors.orange,
        ),
      );
    }

    if (tvoc > 30) {
      alerts.add(
        alertCard(
          "Calidad del aire deficiente",
          "El nivel de TVOC es elevado.",
          Icons.cloud,
          Colors.deepOrange,
        ),
      );
    }

    if (alerts.isEmpty) {
      alerts.add(
        Card(
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Padding(
            padding: EdgeInsets.all(20),
            child: Row(
              children: [

                Icon(
                  Icons.check_circle,
                  color: Colors.green,
                  size: 40,
                ),

                SizedBox(width: 15),

                Expanded(
                  child: Text(
                    "No se detectaron alertas. Todos los parámetros están dentro de los rangos normales.",
                    style: TextStyle(
                      fontSize: 15,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(

      backgroundColor: const Color(0xFFF5F7FA),

      appBar: AppBar(
        title: const Text("Alertas"),
        centerTitle: true,
      ),

      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: alerts,
        ),
      ),
    );
  }

  Widget alertCard(
    String title,
    String description,
    IconData icon,
    Color color,
  ) {

    return Card(
      elevation: 4,

      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),

      margin: const EdgeInsets.only(bottom: 15),

      child: Padding(
        padding: const EdgeInsets.all(18),

        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,

          children: [

            Icon(
              icon,
              color: color,
              size: 40,
            ),

            const SizedBox(width: 15),

            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [

                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: color,
                    ),
                  ),

                  const SizedBox(height: 8),

                  Text(
                    description,
                    style: const TextStyle(
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}