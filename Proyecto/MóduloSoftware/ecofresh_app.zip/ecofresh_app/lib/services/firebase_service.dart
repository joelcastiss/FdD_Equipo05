import 'package:firebase_database/firebase_database.dart';

class FirebaseService {
  final DatabaseReference ref =
      FirebaseDatabase.instance.ref("ecofresh");

  Stream<DatabaseEvent> getData() {
    return ref.onValue;
  }
}
