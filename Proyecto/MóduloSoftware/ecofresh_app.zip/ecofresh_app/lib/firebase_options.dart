import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {

    if (kIsWeb) {
      return web;
    }

    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions no soporta esta plataforma.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyB_3npp0IHfAEw1108HJYpawPkwgIdH_FM',
    authDomain: 'ecofresh-e050b.firebaseapp.com',
    databaseURL: 'https://ecofresh-e050b-default-rtdb.firebaseio.com',
    projectId: 'ecofresh-e050b',
    storageBucket: 'ecofresh-e050b.firebasestorage.app',
    messagingSenderId: '1013723453568',
    appId: '1:1013723453568:web:cc163f16c420d1dbc82e65',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyB_3npp0IHfAEw1108HJYpawPkwgIdH_FM',
    appId: '1:1013723453568:web:cc163f16c420d1dbc82e65',
    messagingSenderId: '1013723453568',
    projectId: 'ecofresh-e050b',
    databaseURL: 'https://ecofresh-e050b-default-rtdb.firebaseio.com',
    storageBucket: 'ecofresh-e050b.firebasestorage.app',
  );
}