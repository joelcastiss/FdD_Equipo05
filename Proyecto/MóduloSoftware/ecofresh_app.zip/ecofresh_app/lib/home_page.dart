import 'package:flutter/material.dart';

import 'screens/dashboard_screen.dart';
import 'screens/history_screen.dart';
import 'screens/alerts_screen.dart';
import 'screens/status_screen.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int currentIndex = 0;

  final List<Widget> screens = const [
    DashboardScreen(),
    HistoryScreen(),
    AlertsScreen(),
    StatusScreen(),
  ];

  final List<String> titles = [
    "EcoFresh",
    "Historial",
    "Alertas",
    "Estado del Sistema",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),

      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        backgroundColor: const Color(0xFFF5F7FA),

        title: Text(
          titles[currentIndex],
          style: const TextStyle(
            color: Color(0xFF2E7D32),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      body: screens[currentIndex],

      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,

          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 15,
              offset: const Offset(0, -3),
            ),
          ],
        ),

        child: BottomNavigationBar(
          currentIndex: currentIndex,
          type: BottomNavigationBarType.fixed,

          backgroundColor: Colors.white,

          selectedItemColor: const Color(0xFF2E7D32),

          unselectedItemColor: Colors.grey,

          selectedLabelStyle: const TextStyle(
            fontWeight: FontWeight.bold,
          ),

          elevation: 0,

          onTap: (index) {
            setState(() {
              currentIndex = index;
            });
          },

          items: const [

            BottomNavigationBarItem(
              icon: Icon(Icons.dashboard_rounded),
              label: "Inicio",
            ),

            BottomNavigationBarItem(
              icon: Icon(Icons.show_chart_rounded),
              label: "Historial",
            ),

            BottomNavigationBarItem(
              icon: Icon(Icons.notifications_active_rounded),
              label: "Alertas",
            ),

            BottomNavigationBarItem(
              icon: Icon(Icons.settings_rounded),
              label: "Estado",
            ),
          ],
        ),
      ),
    );
  }
}