import 'package:flutter/material.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

import '../services/firebase_service.dart';
import 'dart:async';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final FirebaseService firebaseService = FirebaseService();

  double temperatura = 0;
  double humedad = 0;
  double eco2 = 0;
  double tvoc = 0;
  double frescura = 0;
  bool online = false;
  DateTime? ultimaLectura;
  Timer? timer;

  Color getFrescuraColor() {
    if (frescura >= 80) {
      return Colors.green;
    } else if (frescura >= 60) {
      return Colors.orange;
    } else {
      return Colors.red;
    }
  }

  String getEstadoFrescura() {
    if (frescura >= 80) {
      return "Producto Fresco";
    } else if (frescura >= 60) {
      return "Estado Aceptable";
    } else {
      return "Riesgo de Deterioro";
    }
  }

  bool esp32Conectado() {
    if (ultimaLectura == null) {
      return false;
    }

    return DateTime.now().difference(ultimaLectura!).inSeconds < 15;
  }

  @override
  void initState() {
    super.initState();

    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() {});
      }
    });

    firebaseService.getData().listen((event) {
      if (event.snapshot.value != null) {
        final data = event.snapshot.value as Map<dynamic, dynamic>;

        setState(() {
          temperatura = double.tryParse(data["temperatura"].toString()) ?? 0;

          humedad = double.tryParse(data["humedad"].toString()) ?? 0;

          eco2 = double.tryParse(data["eco2"].toString()) ?? 0;

          tvoc = double.tryParse(data["tvoc"].toString()) ?? 0;

          frescura = double.tryParse(data["frescura"].toString()) ?? 0;

          online = data["online"] ?? false;

          ultimaLectura = DateTime.now();
        });
      }
    });
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() {});
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F4),

      appBar: AppBar(
        backgroundColor: const Color(0xFF2E7D32),
        elevation: 0,
        centerTitle: false,

        title: const Row(
          children: [
            Icon(Icons.eco, color: Colors.white),
            SizedBox(width: 10),
            Text(
              "EcoFresh",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 24,
              ),
            ),
          ],
        ),

        actions: [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Row(
              children: [
                Icon(Icons.circle, color: Colors.greenAccent, size: 12),
                SizedBox(width: 6),
                Text("Online", style: TextStyle(color: Colors.white)),
              ],
            ),
          ),
        ],
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),

        child: Column(
          children: [
            Container(
              width: double.infinity,

              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    getFrescuraColor(),
                    getFrescuraColor().withOpacity(0.7),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(25),
                boxShadow: [
                  BoxShadow(
                    color: getFrescuraColor().withOpacity(0.3),
                    blurRadius: 15,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),

              child: Padding(
                padding: const EdgeInsets.all(25),

                child: Column(
                  children: [
                    CircularPercentIndicator(
                      radius: 90,
                      lineWidth: 12,
                      animation: true,

                      percent: frescura <= 0 ? 0 : frescura / 100,

                      progressColor: Colors.white,
                      backgroundColor: Colors.white24,

                      center: Text(
                        "${frescura.toInt()}%",
                        style: const TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),

                    const SizedBox(height: 15),

                    const Text(
                      "Nivel de Frescura",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),

                    const SizedBox(height: 8),

                    Text(
                      getEstadoFrescura(),
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),

              crossAxisCount: 2,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: 1.8,

              children: [
                sensorCard(
                  Icons.thermostat,
                  "${temperatura.toStringAsFixed(1)}°C",
                  "Temperatura",
                  Colors.red,
                ),

                sensorCard(
                  Icons.water_drop,
                  "${humedad.toInt()}%",
                  "Humedad",
                  Colors.blue,
                ),

                sensorCard(
                  Icons.air,
                  "${eco2.toInt()} ppm",
                  "eCO₂",
                  Colors.green,
                ),

                sensorCard(
                  Icons.cloud,
                  "${tvoc.toInt()} ppb",
                  "TVOC",
                  Colors.orange,
                ),
              ],
            ),

            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Estado del Sistema",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),

            const SizedBox(height: 20),

            Card(
              elevation: 3,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),

              child: ListTile(
                leading: Icon(
                  frescura >= 80
                      ? Icons.check_circle
                      : frescura >= 60
                      ? Icons.warning
                      : Icons.error,
                  color: getFrescuraColor(),
                ),
                title: Text(getEstadoFrescura()),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget sensorCard(IconData icon, String value, String title, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),

      child: Padding(
        padding: const EdgeInsets.all(10),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,

          children: [
            Container(
              padding: const EdgeInsets.all(12),

              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                shape: BoxShape.circle,
              ),

              child: Icon(icon, size: 24, color: color),
            ),

            const SizedBox(height: 6),

            Text(
              value,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 5),

            Text(
              title,
              style: TextStyle(color: Colors.grey.shade600, fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }
}
